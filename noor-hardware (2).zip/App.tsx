import React, { useState, useEffect } from 'react';
import { 
  ShoppingCart, Search, Menu, Hammer, Settings, MapPin, 
  Lock, Edit2, Trash2, Plus, Save, ChevronLeft, Home, Package, Clock, Key, Image as ImageIcon, Phone, Mail,
  ShieldCheck, HelpCircle, Info, X, ChevronRight
} from 'lucide-react';
import { Product, CartItem } from './types';
import { INITIAL_PRODUCTS } from './constants';

// --- Utilities ---
const formatPrice = (price: number) => `₹${price.toFixed(2)}`;

const scrollToSection = (id: string) => {
  const element = document.getElementById(id);
  if (element) {
    element.scrollIntoView({ behavior: 'smooth' });
  }
};

// --- Components ---

const Sidebar = ({ isOpen, onClose, setPage }: { isOpen: boolean, onClose: () => void, setPage: (p: string) => void }) => {
  if (!isOpen) return null;

  const handleLinkClick = (action: () => void) => {
    action();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[60] flex justify-end">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm transition-opacity" onClick={onClose}></div>
      
      {/* Drawer */}
      <div className="relative w-80 bg-slate-900 h-full shadow-2xl border-l border-gold-600/20 p-6 overflow-y-auto animate-in slide-in-from-right duration-300">
        <button onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-white">
          <X className="w-8 h-8" />
        </button>

        <div className="mt-8 mb-8">
           <div className="flex items-center gap-3 mb-6">
              <img 
                src="https://lh3.googleusercontent.com/d/18S3EV1LgrfgoYaMMDhU8hg3zK1VGcYln" 
                alt="Noor Hardware" 
                className="h-16 w-auto object-contain"
                referrerPolicy="no-referrer"
              />
              <span className="text-2xl font-serif font-bold text-white">Menu</span>
           </div>
           <div className="h-px bg-slate-800 w-full"></div>
        </div>

        <nav className="space-y-6">
          <div>
            <h4 className="text-gold-500 text-xs font-bold uppercase tracking-wider mb-3">Shop</h4>
            <ul className="space-y-3">
              <li>
                <button onClick={() => handleLinkClick(() => setPage('home'))} className="flex items-center justify-between w-full text-slate-300 hover:text-white group">
                  <span className="flex items-center gap-3"><Home className="w-5 h-5"/> Home</span>
                  <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity"/>
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick(() => setPage('products'))} className="flex items-center justify-between w-full text-slate-300 hover:text-white group">
                   <span className="flex items-center gap-3"><Package className="w-5 h-5"/> All Products</span>
                   <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity"/>
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick(() => setPage('cart'))} className="flex items-center justify-between w-full text-slate-300 hover:text-white group">
                   <span className="flex items-center gap-3"><ShoppingCart className="w-5 h-5"/> My Cart</span>
                   <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity"/>
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-gold-500 text-xs font-bold uppercase tracking-wider mb-3">About Us</h4>
            <ul className="space-y-3">
              <li>
                <button onClick={() => handleLinkClick(() => scrollToSection('footer-about'))} className="flex items-center justify-between w-full text-slate-300 hover:text-white group">
                   <span className="flex items-center gap-3"><Info className="w-5 h-5"/> Our Story</span>
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick(() => setPage('admin'))} className="flex items-center justify-between w-full text-slate-300 hover:text-white group">
                   <span className="flex items-center gap-3"><Lock className="w-5 h-5"/> Admin Dashboard</span>
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-gold-500 text-xs font-bold uppercase tracking-wider mb-3">Support</h4>
            <ul className="space-y-3">
              <li>
                <button onClick={() => handleLinkClick(() => scrollToSection('footer-support'))} className="flex items-center justify-between w-full text-slate-300 hover:text-white group">
                   <span className="flex items-center gap-3"><HelpCircle className="w-5 h-5"/> Policies & Help</span>
                </button>
              </li>
            </ul>
          </div>

           <div>
            <h4 className="text-gold-500 text-xs font-bold uppercase tracking-wider mb-3">Contact</h4>
            <ul className="space-y-3">
              <li>
                <button onClick={() => handleLinkClick(() => scrollToSection('footer-contact'))} className="flex items-center justify-between w-full text-slate-300 hover:text-white group">
                   <span className="flex items-center gap-3"><Phone className="w-5 h-5"/> Contact Info</span>
                </button>
              </li>
            </ul>
          </div>
        </nav>
      </div>
    </div>
  );
};

const Header = ({ 
  cartCount, 
  setPage, 
  page,
  search,
  setSearch
}: { 
  cartCount: number, 
  setPage: (p: string) => void, 
  page: string,
  search: string,
  setSearch: (s: string) => void
}) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  return (
    <>
      <header className="bg-slate-900 text-slate-50 sticky top-0 z-50 shadow-lg border-b border-gold-600/30">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between gap-4">
          
          {/* LEFT: Logo & Time */}
          <div className="flex items-center gap-2 md:gap-6 shrink-0 w-auto md:w-1/4">
            <div 
              className="flex items-center cursor-pointer" 
              onClick={() => setPage('home')}
            >
              <img 
                src="https://lh3.googleusercontent.com/d/18S3EV1LgrfgoYaMMDhU8hg3zK1VGcYln" 
                alt="Noor Hardware Logo" 
                className="h-10 md:h-16 w-auto object-contain filter drop-shadow-md"
                referrerPolicy="no-referrer"
              />
              <div className="ml-2 md:ml-3 block">
                <h1 className="text-lg md:text-2xl font-serif font-bold tracking-wide leading-none text-slate-50">
                  Noor <span className="text-gold-500">Hardware</span>
                </h1>
              </div>
            </div>

            <div className="hidden xl:flex items-center gap-2 text-xs font-medium text-slate-400 border-l border-slate-700 pl-6 h-8">
              <Clock className="w-4 h-4 text-gold-500" />
              <span className="whitespace-nowrap">Opens at 9:00 AM</span>
            </div>
          </div>

          {/* CENTER: Search Bar */}
          <div className="flex-1 flex justify-center max-w-xl px-2 md:px-4">
            <div className="relative group w-full hidden md:block">
              <input 
                type="text" 
                placeholder="Search for tools..." 
                className="w-full pl-12 pr-4 py-3 bg-slate-800 border border-slate-700 rounded-full text-slate-200 focus:bg-slate-900 focus:border-gold-500 focus:ring-1 focus:ring-gold-500 outline-none placeholder-slate-500 transition-all text-base"
                value={search}
                onChange={e => setSearch(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && setPage('products')}
              />
              <Search className="absolute left-4 top-3.5 text-slate-500 w-5 h-5 group-focus-within:text-gold-500 transition-colors" />
            </div>
          </div>

          {/* RIGHT: Navigation Group */}
          <div className="flex items-center justify-end gap-6 shrink-0 w-1/4">
            {/* Desktop Nav Links */}
            <div className="hidden md:flex items-center gap-6">
              <button 
                onClick={() => setPage('home')}
                className={`flex flex-col items-center gap-1 hover:text-gold-400 transition-colors group ${page === 'home' ? 'text-gold-500' : ''}`}
              >
                <div className={`p-1.5 rounded-full transition-colors ${page === 'home' ? 'bg-slate-800' : 'group-hover:bg-slate-800'}`}>
                   <Home className="w-6 h-6" />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wide">Home</span>
              </button>
              
              <button 
                onClick={() => setPage('products')}
                className={`flex flex-col items-center gap-1 hover:text-gold-400 transition-colors group ${page === 'products' ? 'text-gold-500' : ''}`}
              >
                <div className={`p-1.5 rounded-full transition-colors ${page === 'products' ? 'bg-slate-800' : 'group-hover:bg-slate-800'}`}>
                  <Package className="w-6 h-6" />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wide">Products</span>
              </button>

              <button 
                onClick={() => setPage('cart')}
                className={`flex flex-col items-center gap-1 hover:text-gold-400 transition-colors group relative ${page === 'cart' ? 'text-gold-500' : ''}`}
              >
                <div className={`p-1.5 rounded-full transition-colors ${page === 'cart' ? 'bg-slate-800' : 'group-hover:bg-slate-800'}`}>
                  <ShoppingCart className="w-6 h-6" />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wide">Cart</span>
                {cartCount > 0 && (
                  <span className="absolute top-0 right-0 bg-gold-500 text-slate-900 text-[10px] font-bold w-4 h-4 flex items-center justify-center rounded-full border border-slate-900">
                    {cartCount}
                  </span>
                )}
              </button>
            </div>

            {/* Mobile Cart Icon (Only visible on mobile) */}
            <button 
              onClick={() => setPage('cart')}
              className="md:hidden relative hover:text-gold-400 transition"
            >
              <ShoppingCart className="w-6 h-6" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-gold-500 text-slate-900 text-xs font-bold w-4 h-4 flex items-center justify-center rounded-full">
                  {cartCount}
                </span>
              )}
            </button>
            
            {/* Global Menu Button (Visible on All Screens) */}
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="text-slate-300 hover:text-white ml-2 md:ml-4 p-1"
            >
              <Menu className="w-8 h-8" />
            </button>
          </div>
        </div>
        
        {/* Mobile Search Bar */}
        <div className="md:hidden px-4 pb-4">
          <div className="relative">
            <input 
              type="text" 
              placeholder="Search tools..." 
              className="w-full pl-10 pr-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-200 focus:border-gold-500 outline-none"
              value={search}
              onChange={e => setSearch(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && setPage('products')}
            />
            <Search className="absolute left-3 top-2.5 text-slate-500 w-5 h-5" />
          </div>
        </div>
      </header>

      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} setPage={setPage} />
    </>
  );
};

const Hero = ({ setPage }: { setPage: (p: string) => void }) => (
  <section className="relative bg-slate-900 h-[600px] flex items-center overflow-hidden">
    {/* Background Image with Overlay */}
    <div className="absolute inset-0 z-0">
      <img 
         src="https://images.pexels.com/photos/162553/keys-workshop-mechanic-tools-162553.jpeg" 
         alt="Workshop Tools" 
         className="w-full h-full object-cover" 
       />
       {/* Blue/Dark Overlay for text readability and aesthetic */}
       <div className="absolute inset-0 bg-slate-900/80 mix-blend-multiply"></div>
       <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900/60 to-transparent"></div>
    </div>
    
    <div className="container mx-auto px-4 relative z-20">
      <div className="max-w-2xl">
        <h2 className="text-5xl md:text-6xl font-serif font-bold text-slate-50 mb-6 leading-tight drop-shadow-md">
          Your Vision <span className="text-gold-500">Built with Precision</span>
        </h2>
        <p className="text-xl text-slate-200 mb-8 font-light drop-shadow">
          One Stop Solution for All Hardware Needs.
        </p>
        <button 
          onClick={() => setPage('products')}
          className="bg-gold-500 hover:bg-gold-600 text-slate-900 font-bold py-4 px-8 rounded-sm shadow-lg hover:shadow-gold-500/20 transition-all transform hover:-translate-y-1"
        >
          Shop Now
        </button>
      </div>
    </div>
  </section>
);

const ProductCard = ({ product, addToCart }: { product: Product, addToCart: (p: Product) => void }) => (
  <div className="bg-white border border-slate-200 rounded-sm hover:shadow-xl transition-shadow group flex flex-col">
    <div className="relative overflow-hidden aspect-square bg-slate-100">
      <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
      <button 
        onClick={() => addToCart(product)}
        className="absolute bottom-4 right-4 bg-slate-900 text-white p-3 rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-lg hover:bg-gold-500 hover:text-slate-900"
      >
        <ShoppingCart className="w-5 h-5" />
      </button>
    </div>
    <div className="p-4 flex-1 flex flex-col">
      <p className="text-xs text-slate-500 uppercase tracking-wide mb-1">{product.category}</p>
      <h3 className="font-serif text-lg font-bold text-slate-900 mb-2">{product.name}</h3>
      <p className="text-slate-600 text-sm mb-4 line-clamp-2 flex-1">{product.description}</p>
      <div className="flex items-center justify-between mt-auto">
        <span className="text-xl font-bold text-slate-900">{formatPrice(product.price)}</span>
        <button className="text-sm font-semibold text-gold-600 hover:text-gold-700 underline">Details</button>
      </div>
    </div>
  </div>
);

// --- Admin Components ---

const AdminLogin = ({ onLogin, currentPassword }: { onLogin: (status: boolean) => void, currentPassword: string }) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === currentPassword) { 
      onLogin(true);
    } else {
      setError('Invalid password');
    }
  };

  return (
    <div className="min-h-[60vh] flex items-center justify-center bg-slate-100 px-4">
      <div className="bg-white p-8 rounded shadow-lg max-w-md w-full border border-slate-200">
        <div className="flex justify-center mb-6">
          <div className="bg-slate-900 p-4 rounded-full">
            <Lock className="w-8 h-8 text-gold-500" />
          </div>
        </div>
        <h2 className="text-2xl font-serif font-bold text-center text-slate-900 mb-2">Admin Access</h2>
        <p className="text-center text-slate-500 mb-6">Please enter the security key to continue.</p>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 border border-slate-300 rounded focus:border-gold-500 focus:ring-1 focus:ring-gold-500 outline-none transition bg-white"
              placeholder="Enter Password"
            />
          </div>
          {error && <p className="text-red-500 text-sm text-center">{error}</p>}
          <button 
            type="submit"
            className="w-full bg-slate-900 text-white font-bold py-3 rounded hover:bg-gold-500 hover:text-slate-900 transition-colors"
          >
            Unlock Dashboard
          </button>
        </form>
      </div>
    </div>
  );
};

const ProductForm = ({ 
  product, 
  onSave, 
  onCancel 
}: { 
  product?: Product, 
  onSave: (p: Product) => void, 
  onCancel: () => void 
}) => {
  const [formData, setFormData] = useState<Product>(
    product || {
      id: '',
      name: '',
      description: '',
      price: 0,
      image: 'https://picsum.photos/400/400',
      category: 'General'
    }
  );

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'price' ? parseFloat(value) || 0 : value
    }));
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, image: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="bg-white p-8 rounded-lg shadow-xl border border-slate-200">
      <h3 className="text-2xl font-serif font-bold mb-6 text-slate-900 flex items-center gap-2">
        {product ? <Edit2 className="w-6 h-6 text-gold-500"/> : <Plus className="w-6 h-6 text-gold-500"/>}
        {product ? 'Edit Product' : 'Add New Product'}
      </h3>
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
             <div>
              <label className="block text-sm font-bold text-slate-700 mb-1">Product Name</label>
              <input
                name="name"
                value={formData.name}
                onChange={handleChange}
                className="w-full p-3 border border-slate-300 rounded bg-white focus:border-gold-500 outline-none transition shadow-sm"
                placeholder="e.g. Cordless Drill"
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-1">Category</label>
              <input
                name="category"
                value={formData.category}
                onChange={handleChange}
                className="w-full p-3 border border-slate-300 rounded bg-white focus:border-gold-500 outline-none transition shadow-sm"
                placeholder="e.g. Power Tools"
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-1">Price (₹)</label>
              <input
                name="price"
                type="number"
                value={formData.price}
                onChange={handleChange}
                className="w-full p-3 border border-slate-300 rounded bg-white focus:border-gold-500 outline-none transition shadow-sm"
              />
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-1">Product Image</label>
              <div className="border-2 border-dashed border-slate-300 rounded-lg p-4 flex flex-col items-center justify-center bg-slate-50 hover:bg-slate-100 transition relative overflow-hidden group">
                 {formData.image ? (
                   <>
                     <img src={formData.image} alt="Preview" className="h-32 object-contain mb-2 z-10" />
                     <div className="absolute inset-0 bg-black/50 hidden group-hover:flex items-center justify-center z-20 transition-all">
                        <p className="text-white text-sm font-bold">Change Image</p>
                     </div>
                   </>
                 ) : (
                   <div className="text-center py-4">
                     <ImageIcon className="w-10 h-10 text-slate-400 mx-auto mb-2"/>
                     <span className="text-sm text-slate-500">No image selected</span>
                   </div>
                 )}
                 <input 
                   type="file" 
                   accept="image/*" 
                   onChange={handleImageUpload} 
                   className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-30"
                 />
              </div>
              <div className="mt-2 text-center text-xs text-slate-400">
                OR
              </div>
              <input
                name="image"
                value={formData.image}
                onChange={handleChange}
                className="w-full mt-2 p-2 text-xs border border-slate-300 rounded bg-white focus:border-gold-500 outline-none text-slate-500"
                placeholder="Enter Image URL directly..."
              />
            </div>
          </div>
        </div>

        <div>
          <label className="block text-sm font-bold text-slate-700 mb-1">Description</label>
          <textarea
            name="description"
            value={formData.description}
            onChange={handleChange}
            rows={4}
            className="w-full p-3 border border-slate-300 rounded bg-white focus:border-gold-500 outline-none transition shadow-sm"
            placeholder="Detailed description of the tool..."
          />
        </div>

        <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
          <button onClick={onCancel} className="px-6 py-2 text-slate-600 hover:bg-slate-100 rounded font-medium transition">Cancel</button>
          <button 
            onClick={() => onSave(formData)} 
            className="px-6 py-2 bg-gold-500 text-slate-900 font-bold rounded hover:bg-gold-600 flex items-center gap-2 shadow-lg hover:shadow-gold-500/20 transition transform hover:-translate-y-0.5"
          >
            <Save className="w-4 h-4" /> Save Product
          </button>
        </div>
      </div>
    </div>
  );
};

const PasswordChangeForm = ({ onSave, onCancel }: { onSave: (p: string) => void, onCancel: () => void }) => {
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [error, setError] = useState('');

  const handleSave = () => {
    if (newPass.length < 4) {
      setError('Password must be at least 4 characters');
      return;
    }
    if (newPass !== confirmPass) {
      setError('Passwords do not match');
      return;
    }
    onSave(newPass);
  };

  return (
    <div className="max-w-md mx-auto bg-white p-8 rounded shadow border border-slate-200 mt-4">
      <h3 className="text-xl font-bold mb-6 text-slate-900 flex items-center gap-2">
        <Key className="w-5 h-5 text-gold-500" /> Change Admin Password
      </h3>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">New Password</label>
          <input
            type="password"
            value={newPass}
            onChange={(e) => setNewPass(e.target.value)}
            className="w-full p-2 border border-slate-300 rounded focus:border-gold-500 outline-none bg-white"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Confirm New Password</label>
          <input
            type="password"
            value={confirmPass}
            onChange={(e) => setConfirmPass(e.target.value)}
            className="w-full p-2 border border-slate-300 rounded focus:border-gold-500 outline-none bg-white"
          />
        </div>
        {error && <p className="text-red-500 text-sm">{error}</p>}
        <div className="flex justify-end gap-2 mt-4">
          <button onClick={onCancel} className="px-4 py-2 text-slate-600 hover:bg-slate-50 rounded">Cancel</button>
          <button onClick={handleSave} className="px-4 py-2 bg-slate-900 text-white rounded hover:bg-slate-800">Update Password</button>
        </div>
      </div>
    </div>
  );
};

const AdminDashboard = ({ 
  products, 
  onAdd, 
  onEdit, 
  onDelete, 
  onLogout,
  onChangePassword
}: { 
  products: Product[], 
  onAdd: (p: Product) => void, 
  onEdit: (p: Product) => void, 
  onDelete: (id: string) => void, 
  onLogout: () => void,
  onChangePassword: (newPass: string) => void
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [currentProduct, setCurrentProduct] = useState<Product | undefined>(undefined);
  const [showSettings, setShowSettings] = useState(false);

  const handleSave = (product: Product) => {
    if (currentProduct) {
      onEdit(product);
    } else {
      onAdd({ ...product, id: Date.now().toString() });
    }
    setIsEditing(false);
    setCurrentProduct(undefined);
  };

  const startEdit = (product: Product) => {
    setCurrentProduct(product);
    setIsEditing(true);
    setShowSettings(false);
  };

  const startAdd = () => {
    setCurrentProduct(undefined);
    setIsEditing(true);
    setShowSettings(false);
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="flex justify-between items-center mb-8 bg-white p-6 rounded shadow border border-slate-100">
        <h2 className="text-3xl font-serif font-bold text-slate-900">Admin Dashboard</h2>
        <div className="flex gap-3">
          <button 
            onClick={() => { setShowSettings(!showSettings); setIsEditing(false); }}
            className="flex items-center gap-2 px-4 py-2 bg-slate-100 text-slate-700 rounded hover:bg-slate-200"
          >
            <Settings className="w-4 h-4" /> Settings
          </button>
          <button 
            onClick={onLogout} 
            className="px-4 py-2 bg-red-50 text-red-600 rounded hover:bg-red-100 font-medium"
          >
            Logout
          </button>
        </div>
      </div>

      {showSettings ? (
        <PasswordChangeForm 
          onSave={(newPass) => { onChangePassword(newPass); setShowSettings(false); }} 
          onCancel={() => setShowSettings(false)} 
        />
      ) : isEditing ? (
        <ProductForm product={currentProduct} onSave={handleSave} onCancel={() => setIsEditing(false)} />
      ) : (
        <div className="bg-white rounded-lg shadow-lg border border-slate-200 overflow-hidden">
           <div className="p-6 flex justify-between items-center border-b border-slate-100">
             <h3 className="text-xl font-bold text-slate-800">Product Management</h3>
             <button 
                onClick={startAdd} 
                className="bg-gold-500 text-slate-900 px-6 py-2 rounded font-bold flex items-center gap-2 hover:bg-gold-600 transition"
             >
                <Plus className="w-4 h-4" /> Add Product
             </button>
           </div>
           
           <div className="overflow-x-auto">
             <table className="w-full text-left">
               <thead className="bg-slate-50 border-b border-slate-200">
                 <tr>
                   <th className="p-4 font-bold text-slate-600">Image</th>
                   <th className="p-4 font-bold text-slate-600">Name</th>
                   <th className="p-4 font-bold text-slate-600">Category</th>
                   <th className="p-4 font-bold text-slate-600">Price</th>
                   <th className="p-4 font-bold text-slate-600 text-right">Actions</th>
                 </tr>
               </thead>
               <tbody className="divide-y divide-slate-100">
                 {products.map(product => (
                   <tr key={product.id} className="hover:bg-slate-50 transition">
                     <td className="p-4">
                       <img src={product.image} alt={product.name} className="w-12 h-12 rounded object-cover border border-slate-200" />
                     </td>
                     <td className="p-4 font-medium text-slate-900">{product.name}</td>
                     <td className="p-4 text-slate-500">{product.category}</td>
                     <td className="p-4 text-slate-900 font-bold">{formatPrice(product.price)}</td>
                     <td className="p-4 text-right">
                       <div className="flex justify-end gap-2">
                         <button onClick={() => startEdit(product)} className="p-2 text-blue-600 hover:bg-blue-50 rounded"><Edit2 className="w-4 h-4" /></button>
                         <button onClick={() => onDelete(product.id)} className="p-2 text-red-600 hover:bg-red-50 rounded"><Trash2 className="w-4 h-4" /></button>
                       </div>
                     </td>
                   </tr>
                 ))}
               </tbody>
             </table>
           </div>
        </div>
      )}
    </div>
  );
};

const Footer = ({ setPage }: { setPage: (p: string) => void }) => (
  <footer className="bg-slate-900 text-slate-300 py-16 border-t border-gold-600/30">
    <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12">
      {/* Brand Info */}
      <div className="lg:col-span-1">
        <div className="flex items-center gap-2 mb-6">
          <Hammer className="text-gold-500 w-8 h-8" />
          <span className="text-2xl font-serif font-bold text-slate-50">Noor Hardware</span>
        </div>
        <p className="text-slate-400 leading-relaxed mb-6 text-base">
          Premium tools for professionals and DIY enthusiasts. 
          Built for durability, designed for precision.
        </p>
      </div>
      
      {/* Shop Links */}
      <div id="footer-shop">
        <h3 className="text-slate-50 font-bold text-xl mb-6">Shop</h3>
        <ul className="space-y-4 text-base">
          <li><button onClick={() => setPage('home')} className="hover:text-gold-500 transition">Home</button></li>
          <li><button onClick={() => setPage('products')} className="hover:text-gold-500 transition">All Products</button></li>
          <li><button onClick={() => setPage('cart')} className="hover:text-gold-500 transition">My Cart</button></li>
        </ul>
      </div>

      {/* About Us */}
      <div id="footer-about">
        <h3 className="text-slate-50 font-bold text-xl mb-6">About Us</h3>
        <ul className="space-y-4 text-base">
          <li><button className="flex items-center gap-2 hover:text-gold-500 transition text-left"><Info className="w-3 h-3 shrink-0" /> Hardware Store We are wholesalers and retailers of paint rollers, brushes, power tools, hand tool, plumbing, sanitary, colours, padlocks, welding items and equipment</button></li>
          <li><button onClick={() => setPage('admin')} className="flex items-center gap-2 hover:text-gold-500 transition"><Lock className="w-3 h-3" /> Admin Dashboard</button></li>
          <li><button className="hover:text-gold-500 transition">Careers</button></li>
        </ul>
      </div>

      {/* Support */}
      <div id="footer-support">
        <h3 className="text-slate-50 font-bold text-xl mb-6">Support</h3>
        <ul className="space-y-4 text-base">
          <li><button className="hover:text-gold-500 transition flex items-center gap-2"><HelpCircle className="w-4 h-4"/> Return Policy</button></li>
          <li><button className="hover:text-gold-500 transition">Refund Policy</button></li>
          <li><button className="hover:text-gold-500 transition">Product Recalls</button></li>
          <li><button className="hover:text-gold-500 transition">My Preference Center</button></li>
          <li><button className="hover:text-gold-500 transition flex items-center gap-2"><ShieldCheck className="w-4 h-4"/> Privacy & Security</button></li>
        </ul>
      </div>

      {/* Contact */}
      <div id="footer-contact">
        <h3 className="text-slate-50 font-bold text-xl mb-6">Contact Us</h3>
        <ul className="space-y-4 text-base">
           <li className="flex items-start gap-3">
            <MapPin className="w-5 h-5 text-gold-500 mt-1 shrink-0" />
            <a 
              href="https://www.google.com/maps/search/?api=1&query=Silampura+Road,+amaravati+road,+in+front+of+Ankita+talkies,+Sanjay+Nagar+Burhanpur,+Madhya+Pradesh+450331" 
              target="_blank" 
              rel="noopener noreferrer"
              className="hover:text-gold-400 transition"
            >
              Silampura Road, amaravati road, in front of Ankita talkies, Sanjay Nagar, Burhanpur, Madhya Pradesh 450331
            </a>
          </li>
           <li className="flex items-center gap-3">
             <Clock className="w-5 h-5 text-gold-500" />
             <span>Opens at 9:00 AM</span>
           </li>
           <li className="flex items-center gap-3">
             <Phone className="w-5 h-5 text-gold-500" />
             <a href="tel:+919399271263" className="hover:text-gold-400 transition font-medium">
               +91 9755444572
             </a>
           </li>
           <li className="flex items-center gap-3">
             <Mail className="w-5 h-5 text-gold-500" />
             <a href="mailto:info@noorhardware.com" className="hover:text-gold-400 transition">
               ibrahimfakhri10@gmail.com
             </a>
           </li>
        </ul>
      </div>
    </div>
    <div className="container mx-auto px-4 mt-12 pt-8 border-t border-slate-800 text-center text-sm text-slate-500">
      &copy; {new Date().getFullYear()} Noor Hardware. All rights reserved.
    </div>
  </footer>
);

export default function App() {
  const [page, setPage] = useState('home');
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [adminPassword, setAdminPassword] = useState('noorhard123');
  const [search, setSearch] = useState('');

  // Persist admin login
  useEffect(() => {
    const loggedIn = localStorage.getItem('isAdminLoggedIn') === 'true';
    if (loggedIn) setIsAdminLoggedIn(true);
  }, []);

  const handleAdminLogin = (status: boolean) => {
    setIsAdminLoggedIn(status);
    if (status) localStorage.setItem('isAdminLoggedIn', 'true');
  };

  const handleAdminLogout = () => {
    setIsAdminLoggedIn(false);
    localStorage.removeItem('isAdminLoggedIn');
  };

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const handleAddProduct = (product: Product) => {
    setProducts(prev => [...prev, product]);
  };

  const handleEditProduct = (product: Product) => {
    setProducts(prev => prev.map(p => p.id === product.id ? product : p));
  };

  const handleDeleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  const cartTotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  // Filtering products for display
  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(search.toLowerCase()) || 
    p.category.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900">
      <Header 
        cartCount={cart.reduce((a, b) => a + b.quantity, 0)} 
        setPage={setPage} 
        page={page} 
        search={search}
        setSearch={setSearch}
      />

      <main className="flex-grow">
        {page === 'home' && (
          <>
            <Hero setPage={setPage} />
            <section className="container mx-auto px-4 py-16">
              <div className="flex justify-between items-end mb-10">
                <div>
                   <h2 className="text-3xl font-serif font-bold text-slate-900 mb-2">Featured Products</h2>
                   <div className="h-1 w-20 bg-gold-500"></div>
                </div>
                <button onClick={() => setPage('products')} className="text-slate-600 hover:text-gold-600 font-medium flex items-center">
                   View All <ChevronLeft className="w-4 h-4 rotate-180" />
                </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                {filteredProducts.slice(0, 4).map(product => (
                  <ProductCard key={product.id} product={product} addToCart={addToCart} />
                ))}
              </div>
            </section>
          </>
        )}

        {page === 'products' && (
          <div className="container mx-auto px-4 py-12">
            <h2 className="text-3xl font-serif font-bold text-slate-900 mb-8">Our Collection</h2>
            {filteredProducts.length === 0 ? (
               <div className="text-center py-20 bg-white rounded-lg border border-slate-200">
                  <p className="text-slate-500 text-lg">No products found matching "{search}"</p>
                  <button onClick={() => setSearch('')} className="mt-4 text-gold-600 hover:underline">Clear Search</button>
               </div>
            ) : (
               <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-8">
                 {filteredProducts.map(product => (
                   <ProductCard key={product.id} product={product} addToCart={addToCart} />
                 ))}
               </div>
            )}
          </div>
        )}

        {page === 'cart' && (
          <div className="container mx-auto px-4 py-12">
            <h2 className="text-3xl font-serif font-bold text-slate-900 mb-8">Shopping Cart</h2>
            {cart.length === 0 ? (
              <div className="text-center py-20 bg-white rounded shadow-sm border border-slate-200">
                <ShoppingCart className="w-16 h-16 mx-auto text-slate-300 mb-4" />
                <p className="text-xl text-slate-500 mb-6">Your cart is empty.</p>
                <button onClick={() => setPage('products')} className="bg-gold-500 text-slate-900 px-8 py-3 rounded font-bold hover:bg-gold-600 transition">
                  Start Shopping
                </button>
              </div>
            ) : (
              <div className="bg-white rounded shadow-lg border border-slate-200 overflow-hidden">
                <div className="divide-y divide-slate-100">
                  {cart.map(item => (
                    <div key={item.id} className="p-6 flex flex-col md:flex-row items-center gap-6">
                      <img src={item.image} alt={item.name} className="w-24 h-24 object-cover rounded border border-slate-200" />
                      <div className="flex-1 text-center md:text-left">
                        <h3 className="font-bold text-lg text-slate-900">{item.name}</h3>
                        <p className="text-slate-500 text-sm">{formatPrice(item.price)}</p>
                      </div>
                      <div className="flex items-center gap-4 bg-slate-50 p-2 rounded border border-slate-200">
                        <button onClick={() => updateQuantity(item.id, -1)} className="w-8 h-8 flex items-center justify-center bg-white rounded shadow hover:bg-slate-100 font-bold">-</button>
                        <span className="font-bold w-4 text-center">{item.quantity}</span>
                        <button onClick={() => updateQuantity(item.id, 1)} className="w-8 h-8 flex items-center justify-center bg-white rounded shadow hover:bg-slate-100 font-bold">+</button>
                      </div>
                      <div className="text-right min-w-[100px]">
                        <p className="font-bold text-lg text-slate-900">{formatPrice(item.price * item.quantity)}</p>
                      </div>
                      <button onClick={() => removeFromCart(item.id)} className="text-red-500 hover:bg-red-50 p-2 rounded">
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  ))}
                </div>
                <div className="bg-slate-50 p-8 flex flex-col md:flex-row justify-end items-center gap-6 border-t border-slate-200">
                  <div className="text-right">
                    <span className="text-slate-500 text-sm block">Total Amount</span>
                    <span className="text-3xl font-bold text-slate-900">{formatPrice(cartTotal)}</span>
                  </div>
                  <button className="bg-slate-900 text-white px-10 py-4 rounded font-bold hover:bg-gold-500 hover:text-slate-900 transition-colors shadow-lg w-full md:w-auto">
                    Checkout Now
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {page === 'admin' && (
          isAdminLoggedIn ? (
            <AdminDashboard 
              products={products} 
              onAdd={handleAddProduct} 
              onEdit={handleEditProduct} 
              onDelete={handleDeleteProduct}
              onLogout={handleAdminLogout}
              onChangePassword={setAdminPassword}
            />
          ) : (
            <AdminLogin onLogin={handleAdminLogin} currentPassword={adminPassword} />
          )
        )}
      </main>

      <Footer setPage={setPage} />
    </div>
  );
}